<!DOCTYPE html>
<html lang="en">
  <head>
    <title>EAZY TECH</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,700,900" rel="stylesheet">
   <link href="https://fonts.googleapis.com/css2?family=Acme&family=Arbutus+Slab&family=Cabin+Sketch&family=Monoton&family=Playfair+Display:wght@400;500&family=Quicksand:wght@500&family=Roboto+Slab&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">

    <link rel="stylesheet" href="css/jquery.fancybox.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">

    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
    
    <style type="text/css">
      .hd{font-size:20px;margin-bottom: 3px;}
      p{text-align: justify;}
      .service{background-color: black;}
      body{font-family: 'Calibri';}
      .wt{height: 400px;
  width: 100%;}
    </style>
  </head>
  <body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
  
  <div class="site-wrap">

    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>
   
    
    <header class="site-navbar py-4 js-sticky-header site-navbar-target" role="banner">
      
      <div class="container-fluid">
        <div class="d-flex align-items-center">
          <div class="site-logo" style="font-size: 30px;"><a href="index.php">ea<font color="#0099e6">Z</font>y Tech<br><h6 style="font-size: 16px;line-height: 0px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Software<font color="white">_</font>Solutions</h6></a></div>
          <div>
            <nav class="site-navigation position-relative text-right" role="navigation" >
              <ul class="site-menu main-menu js-clone-nav mr-auto d-none d-lg-block">
                <li><a href="#home-section" class="nav-link">Home</a></li>
                <li><a href="#services-section" class="nav-link">Services</a></li>
                <li><a href="#work-section" class="nav-link">Work</a></li>
                <!-- <li><a href="#process-section" class="nav-link">Process</a></li> -->
                
              </ul>
            </nav>
          </div>
          <div class="ml-auto">
            <nav class="site-navigation position-relative text-right" role="navigation">
              <ul class="site-menu main-menu site-menu-dark js-clone-nav mr-auto d-none d-lg-block">
                <li class="cta"><a href="#contact-section" class="nav-link"><span class="rounded border border-primary">Contact</span></a></li>
              </ul>
            </nav>
            <a href="#" class="d-inline-block d-lg-none site-menu-toggle js-menu-toggle text-black float-right"><span class="icon-menu h3"></span></a>
          </div>
        </div>
      </div>
      
    </header>

    <div class="intro-section" id="home-section">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-4 mr-auto" data-aos="fade-up">
            <img src="images/ezy.png" alt="Image" height="40px" class="img-fluid">
            <h1 style="font-size: 40px;opacity: 0.7;margin-top: 15px;">We Love To Build <span class="typed-words" style="font-size:20px;"></span></h1>
            <!-- <p class="mb-5">Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime ipsa nulla sed quis rerum amet natus quas necessitatibus.</p> -->
            <!-- <p><a href="#" class="btn btn-outline-light py-3 px-5">Get Started</a></p> -->

          </div>
          <div class="col-lg-2 ml-auto"  data-aos="fade-up" data-aos-delay="100">
            <figure class="img-absolute">
              <img src="images/home2.png" alt="Image" class="img-fluid">
            </figure>
          </div>
        </div>
      </div>
    </div>




    <div class="site-section section-1">
      
    
      <div class="container">
        <div class="row">
          <div class="col-lg-5 mr-auto mb-5">

            <div class="mb-5">
              <span class="section-sub-title d-block hd">About ea<font color="#0099e6">Z</font>y Tech</span>
              <h2 class="section-title">We are an Expert</h2>
              <p style="text-align: justify;color: black; font-family: 'Roboto Slab', serif;">We help enterprises identity cost-cutting solutions by leveraging technology. With our exceptional product / UX design, and world-class talent in technologies like Cloud Computing, Web development, and business intelligence. eaZy Tech makes it easy for you to take your business to the next level, by providing you with competent business analytics and project management services. Our company is a group of individuals, motivated by a deep appreciation for building elegant and functional applications to fulfill your needs.</p>
            </div>
<!-- 
            <div class="row">
              <div class="col-lg-6">
                
                <div class="counter d-flex align-items-start mb-5" data-aos="fade-up" data-aos-delay="">
                  <div class="icon-wrap"><span class="flaticon-reload text-primary"></span></div>
                  <div class="counter-text">
                    <strong>260</strong>
                    <span>Fast Loading</span>
                  </div>
                </div>

                <div class="counter d-flex align-items-start" data-aos="fade-up" data-aos-delay="100">
                  <div class="icon-wrap"><span class="flaticon-download text-primary"></span></div>
                  <div class="counter-text">
                    <strong>2,500</strong>
                    <span>No. of Downloads </span>
                  </div>
                </div>

              </div>
              <div class="col-lg-6">
                
                <div class="counter d-flex align-items-start mb-5" data-aos="fade-up" data-aos-delay="200">
                  <div class="icon-wrap"><span class="flaticon-monitor text-primary"></span></div>
                  <div class="counter-text">
                    <strong>87</strong>
                    <span>Number of Person</span>
                  </div>
                </div>

                <div class="counter d-flex align-items-start" data-aos="fade-up" data-aos-delay="300">
                  <div class="icon-wrap"><span class="flaticon-chat text-primary"></span></div>
                  <div class="counter-text">
                    <strong>920</strong>
                    <span>Chat Room</span>
                  </div>
                </div>

              </div>
            </div> -->
          </div>

          <div class="col-lg-6">
            <div class="image-absolute-box" >
              <!-- <div class="box" data-aos="fade-up">
                <div class="icon-wrap"><span class="flaticon-vector"></span></div>
                <h3>Creativity is the key</h3> -->
                <!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Obcaecati commodi aspernatur eum eius inventore facilis.</p> -->
              <!-- </div> -->
              <img src="images/about.png" alt="Image"  class="img-fluid">
            </div>
          </div>
        </div>

        
    </div>

   <div class="site-section section-2" id="process-section" >
      <div class="container">
        <!-- <div class="row">
          <div class="col-lg-6 mb-5">
            <span class="section-sub-title d-block">Our Process</span>
            <h2 class="section-title">Our Process</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem possimus distinctio ex. Natus totam voluptatibus animi aspernatur ducimus quas obcaecati mollitia quibusdam temporibus culpa dolore molestias blanditiis consequuntur sunt nisi.</p>
          </div>
        </div> -->
        <div class="row" style="margin-bottom: 30px;">
          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="">
            <div class="process p-3">
              <!-- <span class="number">01</span> -->
              <div> 
                <span class="display-4 text-primary mb-4 d-inline-block">
              <img src="images/pic1.png" height="150px">
            </span>
                <h3>Cloud Based Solutions</h3>
                <p style="font-family: 'Quicksand', sans-serif;">A cloud-based application is an application that operates with the help of cloud data. It can also be considered as a combination of standard web applications and traditional desktop apps. Cloud-based applications can also be operated in the offline mode, just like desktop applications.</p>
              </div>

            </div>
          </div>
          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="100">
            <div class="process p-3">
              <!-- <span class="number">02</span> -->
              <div> 
                <span class=" display-4 text-primary mb-4 d-inline-block">
              <img src="images/pic2.png" height="150px">
            </span>
                <h3>Microsoft Dynamics 365</h3>
                <p style="font-family: 'Quicksand', sans-serif;">Microsoft Dynamics 365 for Finance and Operations (D365),Formerly known as Dynamics AX, delivers enterprise capabilities within a single, cloud-based business platform. D365 can take operational and financial processes within your business to a seamlessly connected applications.</p>
              </div>

            </div>
          </div>
          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
             <div class="process p-3">
              <!-- <span class="number">03</span> -->
              <div> 
                <span class=" display-4 text-primary mb-4 d-inline-block">
              <img src="images/pic3.png" height="150px">
            </span>
                <h3>IOT Solutions</h3>
                <p style="font-family: 'Quicksand', sans-serif;">We provide E2E customized IoT solutions to eliminate mundane, increase productivity, enhance ROI and unlock potential savings that, till date, seemed impossible. Our connected sensor network and dashboards keep you at the helm and either make decision themselves or help you make a decision.</p>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>

 
    <div class="site-section" id="services-section" style="background-image: url('https://leveragegrowth.com/wp-content/uploads/2019/03/oleddigitalwallpapergraphic-1024x427.png');">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 mb-5">
            <span class="section-sub-title d-block hd" style="color: #0099e6;">What we Do</span>
            <h2 class="section-title">Services</h2>
            
          </div>
        </div>
 
      </div>
        
      <div class="owl-carousel nonloop-block-14">
        
        <!-- <div class="service">
          <div>
            <span class="display-4 text-primary mb-4 d-inline-block">
              <img src="images/cloud.png">
            </span>
            <h3 style="color: #00acee;font-size:20px;">Cloud Based Solutions</h3>
            <p>A cloud-based application is an application that operates with the help of cloud data. It can also be considered as a combination of standard web applications and traditional desktop applications.  Cloud-based applications can also be operated in the offline mode, just like desktop applications. </p>
          </div>
        </div> -->


        <div class="service">
          <div>
            <span class="display-4 text-primary mb-4 d-inline-block">
              <img src="images/web.png">
            </span>
            <h3 style="color: #00acee;font-size:20px;">Web Development</h3>
            <p>eaZy tech specialized in creating multi-level enterprise-grade web solutions to meet various corporate needs. We develop customized enterprise web portals, eCommerce solutions, B2B and B2C applications, ERP and CRM software apps, Reporting, Billing & amp, Secure Financial Transaction Processing Systems, etc. <!-- Our enterprise IT and web solutions are built using the latest web technologies and they are secure, robust and scalable which help businesses to reduce overall operational cost and enhance operational efficiency --></p>
          </div>
        </div>

        <!-- <div class="service">
          <div>
            <span class=" display-4 text-primary mb-4 d-inline-block">
              <img src="images/micro.png">
            </span>
            <h3 style="color: #00acee;font-size:20px;">Microsoft Dynamics 365</h3>
            <p> Microsoft Dynamics 365 for Finance and Operations (D365),Formerly known as Dynamics AX, delivers enterprise capabilities within a single, cloud-based business platform. D365 can take operational and financial processes within your business to a seamlessly connected application: supply chain, financials, sales and procurement, and, production.</p>
          </div>
        </div>
 -->

        <div class="service">
          <div>
            <span class="display-4 text-primary mb-4 d-inline-block ">
              <img src="images/mob.png" >
            </span>
            <h3 style="color: #00acee;font-size:20px;">Mobile Applications</h3>
            <p>We design elegant small screens applications to improve your consumer experience, and translates it into the success of your business, ease of operations, and engagement of the consumers with our exceptionally deep understanding of design thinking, user experience, and mobile technologies. <!-- We work with multiple ecosystems to create maximum impact to your end-users. --></p>
          </div>
        </div>

        <!-- <div class="service">
          <div>
            <span class=" display-4 text-primary mb-4 d-inline-block">
              <img src="images/iot.png">
            </span>
            <h3 style="color: #00acee;font-size:20px;">IoT Solutions</h3>
            <p> We provide E2E customized IoT solutions to eliminate mundane, increase productivity, enhance ROI and unlock potential savings that, till date, seemed impossible. Our connected sensor network and dashboards keep you at the helm and either make decision themselves or help you make a decision.</p>
          </div>
        </div> -->

        <div class="service">
          <div>
            <span class="display-4 text-primary mb-4 d-inline-block">
              <img src="images/bpmn.png">
            </span>
            <h3 style="color: #00acee;font-size:20px;">BPMN Solutions</h3>
            <p>Business Process Model and Notation (BPMN) is a standard for business process modeling that provides a graphical notation for specifying business processes in a Business Process Diagram (BPD), based on a flowcharting technique. <!-- very similar to activity diagrams from Unified Modeling Language (UML). --></p>
          </div>
        </div>

      </div>

    </div>


   <!--  <div class="site-section section-2" id="work-section">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 mb-5">
            <span class="section-sub-title d-block hd">Excellent Work</span>
            <h2 class="section-title">Our Works</h2>
            
          </div>
        </div>

      </div>
        




      <div class="owl-carousel nonloop-block-13">

          <a class="work-thumb wt" href="images/wrk1.png" data-fancybox="gallery">
            <div class="work-text">
              <h3>Work Name Here</h3>
              <span class="category">Website</span>
            </div>
            <img src="images/wrk1.png" alt="Image" class="img-fluid">
          </a> 
          
          <a class="work-thumb wt" href="images/wrk2.png"  data-fancybox="gallery">
            <div class="work-text">
              <h3>Work Name Here</h3>
              <span class="category">Illustration</span>
            </div>
            <img src="images/wrk2.png" alt="Image" class="img-fluid">
          </a>

          <a class="work-thumb wt" href="images/wrk3.png"  data-fancybox="gallery">
            <div class="work-text">
              <h3>Work Name Here</h3>
              <span class="category">Branding</span>
            </div>
            <img src="images/wrk3.png" alt="Image" class="img-fluid">
          </a>

          <a class="work-thumb wt" href="images/wrk4.png.jpg"  data-fancybox="gallery">
            <div class="work-text">
              <h3>Work Name Here</h3>
              <span class="category">Web Development</span>
            </div>
            <img src="images/wrk4.png" alt="Image" class="img-fluid">
          </a>

          <a class="work-thumb wt" href="images/wrk5.png"  data-fancybox="gallery">
            <div class="work-text">
              <h3>Work Name Here</h3>
              <span class="category">Design</span>
            </div>
            <img src="images/wrk5.png" alt="Image" class="img-fluid">
          </a>
      </div>

    </div> -->

    <div class="site-section section-2" id="work-section">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 mb-5">
            <span class="section-sub-title d-block hd">Happy Clients</span>
            <h2 class="section-title">Partners With</h2>
            
          </div>
        </div>

      </div>
      
      <div class="owl-carousel nonloop-block-13">
        <a class="work-thumb" href=""  data-fancybox="gallery" style="margin: 50px;margin-top:0px;">
            <img src="images/hp1.png">
          </a>
          <a class="work-thumb" href=""  data-fancybox="gallery" style="margin: 50px;margin-top:0px;">
            <img src="images/hp2.png" alt="Image" class="img-fluid">
          </a>
          <a class="work-thumb" href=""  data-fancybox="gallery" style="margin: 50px;margin-top:0px;">
            <img src="images/hp3.png" alt="Image" class="img-fluid">
          </a>
          <!-- <a class="work-thumb" href=""  data-fancybox="gallery" style="margin: 50px;margin-top:0px;">
            <img src="https://image.freepik.com/free-vector/blue-tech-logo_1103-822.jpg" alt="Image" class="img-fluid">
          </a> -->
      </div>
    </div>
    <!-- <section>
   <?php //include "client.php"; ?>
    </section> -->
     <section class="site-section" id="contact-section" style="background-image: url('https://images.pexels.com/photos/1078850/pexels-photo-1078850.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940');">
      <div class="container">
        <div class="row mb-5">
          <div class="col-12 ">
            <span class="section-sub-title d-block hd">Get in Touch</span>
            <h2 class="section-title mb-3" style="color: white;">Contact Us</h2>
          </div>
        </div>
        <div class="row">
          <div class="col-md-7 mb-5">

            

            <form action="#" class="p-5 " style="background-color: #0090c7;opacity: 0.8;">
              
<!--               <h2 class="h4 text-black mb-5">Contact Form</h2> --> 

              <div class="row form-group">
                <div class="col-md-6 mb-3 mb-md-0">
                  <label class="text-black" for="fname">First Name</label>
                  <input type="text" id="fname" class="form-control">
                </div>
                <div class="col-md-6">
                  <label class="text-black" for="lname">Last Name</label>
                  <input type="text" id="lname" class="form-control">
                </div>
              </div>

              <div class="row form-group">
                
                <div class="col-md-12">
                  <label class="text-black" for="email">Email</label> 
                  <input type="email" id="email" class="form-control">
                </div>
              </div>

              <div class="row form-group">
                
                <div class="col-md-12">
                  <label class="text-black" for="subject">Subject</label> 
                  <input type="subject" id="subject" class="form-control">
                </div>
              </div>

              <div class="row form-group">
                <div class="col-md-12">
                  <label class="text-black" for="message">Message</label> 
                  <textarea name="message" id="message" cols="30" rows="4" class="form-control" placeholder="Write your notes or questions here..."></textarea>
                </div>
              </div>

              <div class="row form-group">
                <div class="col-md-12">
                  <input type="submit" value="Send Message" class="btn btn-primary btn-md text-white">
                </div>
              </div>

  
            </form>
          </div>
          <div class="col-md-5">
            
            <div class="p-4 mb-3 " style="background-color: #000;opacity: 0.9;" >
              <p class="mb-0 font-weight-bold">Address</p>
              <p class="mb-4">203 Fake St. Mountain View, San Francisco, California, USA</p>

              <p class="mb-0 font-weight-bold">Phone</p>
              <p class="mb-4"><a href="#">+1 232 3235 324</a></p>

              <p class="mb-0 font-weight-bold">Email Address</p>
              <p class="mb-0"><a href="#">youremail@domain.com</a></p>

            </div>
            
          </div>
        </div>
      </div>
    </section>


    <!-- <div class="site-section" id="contact-section" style="background-color: #e6f0ff;">
      <div class="container">

        <div class="row justify-content-center">
          <div class="col-md-7">


            <span class="section-sub-title d-block hd">Get in Touch</span>
            <h2 class="section-title mb-3">Contact Us</h2>
            
          
            <form method="post" data-aos="fade">
              <div class="form-group row">
                <div class="col-md-6 mb-3 mb-lg-0">
                  <input type="text" class="form-control" placeholder="First name">
                </div>
                <div class="col-md-6">
                  <input type="text" class="form-control" placeholder="Last name">
                </div>
              </div>

              <div class="form-group row">
                <div class="col-md-12">
                  <input type="text" class="form-control" placeholder="Subject">
                </div>
              </div>

              <div class="form-group row">
                <div class="col-md-12">
                  <input type="email" class="form-control" placeholder="Email">
                </div>
              </div>
              <div class="form-group row">
                <div class="col-md-12">
                  <textarea class="form-control" id="" cols="30" rows="10" placeholder="Write your message here."></textarea>
                </div>
              </div>

              <div class="form-group row">
                <div class="col-md-6">
                  
                  <input type="submit" class="btn btn-primary py-3 px-5 btn-block" value="Send Message">
                </div>
              </div>

            </form>
          </div>
        </div>
      </div>
    </div> -->

  
     
    <footer class="footer-section">
      <div class="container">
         <div class="text-center" style="padding-top: 40px;padding-bottom: 0px;" >
        <a href=""><img src="images/facebook.png" height="50px" ></a>
        <a href=""><img src="images/instagram.png" height="50px" style="margin-left: 20px;"></a>
        <a href=""><img src="images/linkedin.png" height="50px" style="margin-left: 20px;"></a>
        <a href=""><img src="images/twitter.png" height="50px" style="margin-left: 20px;"></a>
      </div>
<!--         <div class="row">
          <div class="col-md-4">
            <h3>About Amplify</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Porro consectetur ut hic ipsum et veritatis corrupti. Itaque eius soluta optio dolorum temporibus in, atque, quos fugit sunt sit quaerat dicta.</p>
          </div>

          <div class="col-md-3 ml-auto">
            <h3>Links</h3>
            <ul class="list-unstyled footer-links">
              <li><a href="#">Home</a></li>
              <li><a href="#">Work</a></li>
              <li><a href="#">Process</a></li>
              <li><a href="#">Services</a></li>
            </ul>
          </div>

          <div class="col-md-4">
            <h3>Subscribe</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt incidunt iure iusto architecto? Numquam, natus?</p>
            <form action="#">
              <div class="d-flex mb-5">
                <input type="text" class="form-control rounded-0" placeholder="Email">
                <input type="submit" class="btn btn-primary rounded-0" value="Subscribe">
              </div>
            </form>
          </div>

        </div> -->

        <div class="row pt-5 mt-5 text-center">
          <div class="col-md-12">
            <div class="border-top pt-5">
            <p>
        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
        Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved <!-- | This template is made with <i class="icon-heart" aria-hidden="true"></i> --> by <a href="https://techvyassa.com" target="_blank" >Tech Vyassa</a>
        <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
      </p>
            </div>
          </div>
          
        </div>
      </div>
    </footer>

  
    
  </div> <!-- .site-wrap -->


  <script src="js/typed.js"></script>
            <script>
            var typed = new Typed('.typed-words', {
            strings: ["Web Application"," Cloud Based Application","IOT Applications"],
            typeSpeed: 80,
            backSpeed: 80,
            backDelay: 4000,
            startDelay: 1000,
            loop: true,
            showCursor: true
            });
            </script>

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.fancybox.min.js"></script>
  <script src="js/jquery.sticky.js"></script>

  
  <script src="js/main.js"></script>
    
  </body>
</html>